# GeoSurePath Bug Fixes

## Files Changed

| File | Bug Fixed |
|------|-----------|
| `services/api-server/src/auth/strategies/jwt.strategy.ts` | Bug 1: JWT payload field `phone` → `mobile` |
| `services/api-server/src/api/billing.controller.ts` | Bug 2: `req.user.id` → `req.user.userId`; `req.user.administrator` → `req.user.role !== 'ADMIN'` |
| `services/api-server/src/api/auth.controller.ts` | Bug 3: SQL injection in seeding → parameterized queries |
| `frontend/client-dashboard/src/context/AuthContext.jsx` | Bug 4: Added `refreshUser()` function |
| `frontend/client-dashboard/src/pages/Register.jsx` | Bug 5: `window.location.href` → `refreshUser()` + `navigate()` |
| `frontend/client-dashboard/vite.config.js` | Bug 6: Removed `define: {'process.env': {}}` that broke env vars |
| `frontend/client-dashboard/src/pages/BillingPage.jsx` | Bug 7: `process.env.REACT_APP_*` → `import.meta.env.VITE_*`; invoice as modal not broken JSON download; Razorpay error handling |

## Deployment Steps

### 1. Add required env variable to your `.env`
```
VITE_RAZORPAY_KEY_ID=rzp_live_xxxxxxxxxxxx    # or rzp_test_xxx for testing
```

### 2. Replace the files in your repository with the fixed versions

### 3. Rebuild the frontend
```bash
cd frontend/client-dashboard
npm run build
```

### 4. Restart the API server
```bash
cd services/api-server
npm run build && npm run start:prod
```

## Bug Details

### Bug 1 — JWT field mismatch (`phone` vs `mobile`)
The `loginByMobile` method signed JWTs with `{ sub, mobile, role }`.
The JWT strategy was extracting `payload.phone` (undefined).
Result: `req.user.mobile` was always `undefined` in every authenticated route.

### Bug 2 — Billing controller used wrong user property
JWT strategy returns `{ userId, mobile, role }` on `req.user`.
The billing controller was reading `req.user.id` (undefined) and `req.user.administrator` (undefined).
Result: All billing operations failed with null userId; admin checks always passed or always failed.

### Bug 3 — SQL injection in register seeding
Admin password hash was interpolated directly into an SQL string template literal.
A bcrypt hash could theoretically contain characters that break SQL strings.
Fixed to parameterized queries `($1, $2, ...)`.

### Bug 4 & 5 — Registration redirected without updating React auth state
After `completeProfile()`, the code used `window.location.href = "/dashboard"`.
This triggers a full browser reload. On reload the AuthContext initialises and calls
`getAccount()` — BUT `ProtectedRoute` reads `user` state which starts as `null`.
Because `loading` is `true` while `getAccount()` runs, the child renders nothing.
In some timing windows `ProtectedRoute` redirected to `/login` before the profile loaded.
Fix: Added `refreshUser()` to AuthContext, called before `navigate("/dashboard")`.

### Bug 6 — `process.env: {}` in vite.config killed all env variables
Vite does NOT polyfill `process.env`. The line `define: { 'process.env': {} }` replaced
the entire process.env with an empty object, meaning ALL environment variables read
via `process.env.X` returned `undefined` — including `REACT_APP_RAZORPAY_KEY_ID`.

### Bug 7 — Razorpay key used CRA-style env var name in a Vite project
- Changed: `process.env.REACT_APP_RAZORPAY_KEY_ID`
- To: `import.meta.env.VITE_RAZORPAY_KEY_ID`
- Invoice download fixed: was saving raw JSON as `.json`, now opens a readable modal.
- Added `payment.failed` error handler on Razorpay instance.
- Added missing Razorpay SDK script tag.
