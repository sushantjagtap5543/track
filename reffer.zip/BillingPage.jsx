import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
  CreditCard, Calendar, ShieldCheck, Download, RefreshCcw,
  DollarSign, Clock, ShieldAlert, X, FileText
} from "lucide-react";

// ── Invoice Preview Modal ────────────────────────────────────────────────────
function InvoiceModal({ invoice, onClose }) {
  const handlePrint = () => window.print();

  return (
    <div className="modal-overlay" style={{ zIndex: 10001 }}>
      <div
        className="card modal-content animate-slide-up"
        style={{ width: '560px', maxHeight: '80vh', overflowY: 'auto' }}
      >
        <header
          style={{
            display: 'flex', justifyContent: 'space-between',
            alignItems: 'center', marginBottom: '2rem'
          }}
        >
          <h3 style={{ margin: 0 }}>Invoice Preview</h3>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button className="btn glass-bright" onClick={handlePrint}>
              <Download size={16} style={{ marginRight: '6px' }} /> Print / Save PDF
            </button>
            <button className="btn-icon" onClick={onClose}><X size={20} /></button>
          </div>
        </header>

        {/* Invoice body */}
        <div id="invoice-print-area" style={{ fontFamily: 'sans-serif', fontSize: '0.9rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2rem' }}>
            <div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--primary)' }}>GeoSurePath</div>
              <div style={{ color: 'var(--text-dim)', fontSize: '0.8rem' }}>Fleet Intelligence Platform</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontWeight: 700 }}>Invoice #{invoice.invoiceNumber}</div>
              <div style={{ color: 'var(--text-dim)', fontSize: '0.8rem' }}>
                {new Date(invoice.date).toLocaleDateString('en-IN', {
                  year: 'numeric', month: 'long', day: 'numeric'
                })}
              </div>
            </div>
          </div>

          <div
            style={{
              background: 'rgba(255,255,255,0.04)', borderRadius: '12px',
              padding: '1rem 1.5rem', marginBottom: '2rem'
            }}
          >
            <div style={{ fontWeight: 700, marginBottom: '0.5rem' }}>Billed To</div>
            <div>{invoice.customer?.name || '—'}</div>
            <div style={{ color: 'var(--text-dim)', fontSize: '0.85rem' }}>{invoice.customer?.email || '—'}</div>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '1.5rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                <th style={{ textAlign: 'left', padding: '0.5rem 0', fontWeight: 700 }}>Description</th>
                <th style={{ textAlign: 'right', padding: '0.5rem 0', fontWeight: 700 }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items?.map((item, i) => (
                <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <td style={{ padding: '0.75rem 0' }}>{item.description}</td>
                  <td style={{ padding: '0.75rem 0', textAlign: 'right' }}>
                    ₹{Number(item.amount).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', alignItems: 'flex-end' }}>
            <div style={{ display: 'flex', gap: '3rem' }}>
              <span style={{ color: 'var(--text-dim)' }}>Subtotal</span>
              <span>₹{Number(invoice.totals?.subtotal).toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', gap: '3rem' }}>
              <span style={{ color: 'var(--text-dim)' }}>GST (18%)</span>
              <span>₹{Number(invoice.totals?.tax).toFixed(2)}</span>
            </div>
            <div
              style={{
                display: 'flex', gap: '3rem', fontWeight: 800,
                fontSize: '1.1rem', borderTop: '1px solid var(--border)', paddingTop: '0.5rem', marginTop: '0.25rem'
              }}
            >
              <span>Total</span>
              <span style={{ color: 'var(--primary)' }}>₹{Number(invoice.totals?.total).toFixed(2)}</span>
            </div>
          </div>

          <div
            style={{
              marginTop: '2rem', textAlign: 'center', padding: '0.75rem',
              borderRadius: '10px',
              background: invoice.status === 'captured'
                ? 'rgba(16,185,129,0.1)' : 'rgba(245,158,11,0.1)',
              color: invoice.status === 'captured' ? 'var(--success)' : '#f59e0b',
              fontWeight: 700, fontSize: '0.85rem'
            }}
          >
            Payment Status: {invoice.status === 'captured' ? '✓ Paid' : '⏳ Pending'}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main Billing Page ────────────────────────────────────────────────────────
export default function BillingPage() {
  const [plans, setPlans] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [invoiceModal, setInvoiceModal] = useState(null);
  const [showCashModal, setShowCashModal] = useState(false);
  const [cashForm, setCashForm] = useState({ imei: "", amount: "", notes: "" });
  const [payError, setPayError] = useState("");

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [plansRes, historyRes] = await Promise.all([
        api.get("/billing/plans"),
        api.get("/billing/history"),
      ]);
      setPlans(plansRes.data);
      setHistory(historyRes.data);
    } catch (err) {
      console.error("Failed to fetch billing data", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCashSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/billing/client/cash-record", {
        imei: cashForm.imei,
        amount: Number(cashForm.amount),
        notes: cashForm.notes,
      });
      alert("Cash payment request submitted. Awaiting admin verification.");
      setShowCashModal(false);
      setCashForm({ imei: "", amount: "", notes: "" });
      fetchData();
    } catch (err) {
      alert("Submission failed: " + (err.response?.data?.message || err.message));
    }
  };

  // Opens invoice in a readable modal — avoids broken JSON blob download
  const handleViewInvoice = async (payId) => {
    try {
      const { data } = await api.get(`/invoices/${payId}`);
      setInvoiceModal(data);
    } catch (err) {
      alert("Could not load invoice: " + (err.response?.data?.message || err.message));
    }
  };

  const handlePay = async (plan) => {
    setPayError("");
    // Read Razorpay key from Vite env (must be prefixed VITE_)
    const razorpayKey = import.meta.env.VITE_RAZORPAY_KEY_ID;
    if (!razorpayKey) {
      setPayError(
        "Payment gateway not configured. Add VITE_RAZORPAY_KEY_ID to your .env file."
      );
      return;
    }

    if (!window.Razorpay) {
      setPayError("Razorpay script not loaded. Check your internet connection.");
      return;
    }

    try {
      const { data: order } = await api.post("/billing/order", { planId: plan.slug });

      const options = {
        key: razorpayKey,
        amount: order.amount,
        currency: order.currency,
        name: "GeoSurePath",
        description: `Subscription: ${plan.name}`,
        order_id: order.id,
        handler: async (response) => {
          try {
            await api.post("/billing/verify", {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              imei: "ALL_DEVICES",
            });
            alert("Subscription activated successfully!");
            fetchData();
          } catch (verifyErr) {
            alert(
              "Payment captured but verification failed: " +
              (verifyErr.response?.data?.message || verifyErr.message)
            );
          }
        },
        prefill: {},
        theme: { color: "#06B6D4" },
        modal: {
          ondismiss: () => console.log("Razorpay checkout dismissed"),
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", (resp) => {
        alert("Payment failed: " + resp.error.description);
      });
      rzp.open();
    } catch (err) {
      setPayError(
        "Could not create payment order: " +
        (err.response?.data?.message || err.message)
      );
    }
  };

  if (loading)
    return (
      <div className="p-10 text-center animate-pulse">
        Loading billing information...
      </div>
    );

  return (
    <div
      className="billing-client-page animate-fade-in container"
      style={{ padding: '2rem' }}
    >
      {/* Razorpay SDK — loaded lazily */}
      <script src="https://checkout.razorpay.com/v1/checkout.js" async />

      <header style={{ marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 900, letterSpacing: '-1.5px' }}>
          Billing & Subscriptions
        </h1>
        <p style={{ color: 'var(--text-dim)', fontSize: '1.1rem' }}>
          Manage your prepaid subscription plans and payment history.
        </p>
      </header>

      {/* Pay Error Banner */}
      {payError && (
        <div
          style={{
            background: 'rgba(244,63,94,0.12)', color: '#fb7185', padding: '14px',
            borderRadius: '16px', border: '1px solid rgba(244,63,94,0.2)',
            fontSize: '0.9rem', marginBottom: '2rem',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center'
          }}
        >
          {payError}
          <button
            className="btn-icon"
            onClick={() => setPayError("")}
            style={{ color: '#fb7185' }}
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Plans Grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '2rem', marginBottom: '4rem'
        }}
      >
        {plans.map((plan) => (
          <div
            key={plan.id}
            className="card"
            style={{
              padding: '2.5rem', textAlign: 'center',
              borderTop: '4px solid var(--primary)',
              position: 'relative', overflow: 'hidden'
            }}
          >
            {plan.slug === '12month' && (
              <div
                style={{
                  position: 'absolute', top: '12px', right: '-30px',
                  background: 'var(--success)', color: 'white',
                  padding: '4px 40px', fontSize: '0.7rem', fontWeight: 800,
                  transform: 'rotate(45deg)'
                }}
              >
                BEST VALUE
              </div>
            )}
            <h3 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '0.5rem' }}>
              {plan.name}
            </h3>
            <div
              style={{
                fontSize: '3rem', fontWeight: 900,
                color: 'var(--primary)', marginBottom: '1.5rem'
              }}
            >
              <span style={{ fontSize: '1.2rem', verticalAlign: 'super' }}>₹</span>
              {plan.amount}
            </div>
            <div
              style={{
                marginBottom: '2rem', display: 'flex',
                flexDirection: 'column', gap: '0.75rem',
                fontSize: '0.9rem', color: 'var(--text-dim)'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'center' }}>
                <ShieldCheck size={16} color="var(--success)" /> 24/7 Fleet Monitoring
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'center' }}>
                <Clock size={16} color="var(--primary)" /> {plan.validityMonths} Month{plan.validityMonths > 1 ? 's' : ''} Access
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'center' }}>
                <ShieldAlert size={16} color="var(--primary)" /> Prepaid Plan
              </div>
            </div>
            <button
              className="btn btn-primary"
              style={{ width: '100%', height: '54px', borderRadius: '16px' }}
              onClick={() => handlePay(plan)}
            >
              Activate Plan
            </button>
            <p style={{ marginTop: '1rem', fontSize: '0.7rem', color: 'var(--text-dim)' }}>
              +18% GST applied at checkout.
            </p>
          </div>
        ))}
      </div>

      {/* History + Sidebar */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '3rem' }}>
        {/* Transaction History */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div
            style={{
              padding: '1.5rem 2.5rem', borderBottom: '1px solid var(--border)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center'
            }}
          >
            <h3 style={{ margin: 0, fontWeight: 800 }}>Payment History</h3>
            <button className="btn glass-bright" onClick={fetchData}>
              <RefreshCcw size={16} />
            </button>
          </div>

          {history.length === 0 ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-dim)' }}>
              No payments yet.
            </div>
          ) : (
            <table style={{ background: 'transparent' }}>
              <thead>
                <tr>
                  <th>Transaction ID</th>
                  <th>Method</th>
                  <th>Amount</th>
                  <th>Date</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {history.map((pay) => (
                  <tr key={pay.id}>
                    <td>
                      <code style={{ fontSize: '0.8rem', color: 'var(--primary)' }}>
                        {pay.paymentId || pay.orderId.substring(0, 14)}
                      </code>
                    </td>
                    <td
                      style={{
                        textTransform: 'uppercase',
                        fontSize: '0.75rem', fontWeight: 700
                      }}
                    >
                      {pay.attributes?.method || 'ONLINE'}
                    </td>
                    <td>
                      <span style={{ fontWeight: 800 }}>₹{pay.amount}</span>
                    </td>
                    <td>{new Date(pay.createdAt).toLocaleDateString('en-IN')}</td>
                    <td
                      style={{
                        textAlign: 'right', display: 'flex',
                        gap: '8px', justifyContent: 'flex-end', alignItems: 'center'
                      }}
                    >
                      <span
                        className={`badge ${pay.status === 'captured' ? 'badge-success' : 'badge-warning'}`}
                      >
                        {pay.status === 'captured' ? 'Paid' : 'Pending'}
                      </span>
                      <button
                        className="btn-icon"
                        title="View Invoice"
                        onClick={() => handleViewInvoice(pay.id)}
                      >
                        <FileText size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Sidebar */}
        <div>
          <div
            className="card"
            style={{
              marginBottom: '2rem',
              background: 'rgba(6, 182, 212, 0.05)',
              border: '1px dashed var(--primary)'
            }}
          >
            <h4
              style={{
                fontWeight: 800, marginBottom: '1rem',
                display: 'flex', alignItems: 'center', gap: '10px'
              }}
            >
              <DollarSign size={18} /> Cash Payment
            </h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-dim)', lineHeight: 1.6 }}>
              Paid offline? Submit your payment details here for admin verification.
            </p>
            <button
              className="btn-primary"
              style={{ width: '100%', marginTop: '1.5rem' }}
              onClick={() => setShowCashModal(true)}
            >
              Record Cash Payment
            </button>
          </div>

          <div className="card">
            <h4 style={{ fontWeight: 800, marginBottom: '1.5rem' }}>Security</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div style={{ display: 'flex', gap: '1rem' }}>
                <div
                  style={{
                    padding: '8px',
                    background: 'rgba(16, 185, 129, 0.1)',
                    borderRadius: '10px', color: 'var(--success)'
                  }}
                >
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 700 }}>PCI-DSS Level 1</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>Payments via Razorpay</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '1rem' }}>
                <div
                  style={{
                    padding: '8px',
                    background: 'rgba(6, 182, 212, 0.1)',
                    borderRadius: '10px', color: 'var(--primary)'
                  }}
                >
                  <CreditCard size={20} />
                </div>
                <div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 700 }}>Instant Activation</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>Zero downtime renewal</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cash Payment Modal */}
      {showCashModal && (
        <div className="modal-overlay" style={{ zIndex: 10000 }}>
          <div
            className="card modal-content animate-slide-up"
            style={{ width: '450px' }}
          >
            <header
              style={{
                display: 'flex', justifyContent: 'space-between',
                alignItems: 'center', marginBottom: '2rem'
              }}
            >
              <h3 style={{ margin: 0 }}>Record Cash Payment</h3>
              <button className="btn-icon" onClick={() => setShowCashModal(false)}>
                <X size={20} />
              </button>
            </header>
            <form
              onSubmit={handleCashSubmit}
              style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}
            >
              <div className="input-group">
                <label className="label">Device IMEI</label>
                <input
                  type="text"
                  placeholder="Enter IMEI for renewal"
                  required
                  value={cashForm.imei}
                  onChange={(e) => setCashForm({ ...cashForm, imei: e.target.value })}
                />
              </div>
              <div className="input-group">
                <label className="label">Amount Paid (₹)</label>
                <input
                  type="number"
                  placeholder="Enter amount"
                  required
                  min="1"
                  value={cashForm.amount}
                  onChange={(e) => setCashForm({ ...cashForm, amount: e.target.value })}
                />
              </div>
              <div className="input-group">
                <label className="label">Notes / Reference</label>
                <textarea
                  rows="3"
                  placeholder="Receipt number, executive name, etc."
                  value={cashForm.notes}
                  onChange={(e) => setCashForm({ ...cashForm, notes: e.target.value })}
                />
              </div>
              <button
                type="submit"
                className="btn-primary"
                style={{ width: '100%', padding: '1.25rem' }}
              >
                Submit for Verification
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Preview Modal */}
      {invoiceModal && (
        <InvoiceModal
          invoice={invoiceModal}
          onClose={() => setInvoiceModal(null)}
        />
      )}
    </div>
  );
}
