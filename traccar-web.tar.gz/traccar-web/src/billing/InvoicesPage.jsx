import React, { useState } from 'react';
import { Container, Typography, Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Chip, CircularProgress, IconButton } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import SaaSLayout from '../common/components/SaaSLayout';
import { useEffectAsync } from '../reactHelper';
import FileDownloadIcon from '@mui/icons-material/FileDownload';

const useStyles = makeStyles()((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
  },
  table: {
    borderRadius: '16px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.05)',
    overflow: 'hidden',
  },
  headerCell: {
    backgroundColor: '#f8f9fa',
    fontWeight: 'bold',
  }
}));

const InvoicesPage = () => {
  const { classes } = useStyles();
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffectAsync(async () => {
    try {
      const token = window.localStorage.getItem('geosurepath_token');
      const res = await fetch('/api/billing/history', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setPayments(await res.json());
      }
    } catch (error) {
      console.error('Failed to fetch payment history:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'COMPLETED': return 'success';
      case 'FAILED': return 'error';
      case 'CREATED': return 'warning';
      default: return 'default';
    }
  };

  if (loading) {
    return (
      <SaaSLayout>
        <Box display="flex" justifyContent="center" alignItems="center" height="100%">
          <CircularProgress />
        </Box>
      </SaaSLayout>
    );
  }

  return (
    <SaaSLayout>
      <Container maxWidth="lg" className={classes.container}>
        <Box mb={4}>
          <Typography variant="h4" fontWeight="800" gutterBottom>Billing History</Typography>
          <Typography variant="body1" color="textSecondary">View and download your past invoices.</Typography>
        </Box>

        <TableContainer component={Paper} className={classes.table}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell className={classes.headerCell}>Date</TableCell>
                <TableCell className={classes.headerCell}>Transaction ID</TableCell>
                <TableCell className={classes.headerCell}>Amount</TableCell>
                <TableCell className={classes.headerCell}>Status</TableCell>
                <TableCell className={classes.headerCell}>Method</TableCell>
                <TableCell className={classes.headerCell} align="right">Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {payments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                    <Typography variant="body2" color="textSecondary">No payments found.</Typography>
                  </TableCell>
                </TableRow>
              ) : payments.map((payment) => (
                <TableRow key={payment.id} hover>
                  <TableCell>{new Date(payment.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell sx={{ fontFamily: 'monospace' }}>{payment.transactionId}</TableCell>
                  <TableCell fontWeight="bold">₹{payment.amount}</TableCell>
                  <TableCell>
                    <Chip label={payment.status} size="small" color={getStatusColor(payment.status)} sx={{ fontWeight: 600 }} />
                  </TableCell>
                  <TableCell>{payment.paymentMethod || '-'}</TableCell>
                  <TableCell align="right">
                    <IconButton size="small" color="primary">
                      <FileDownloadIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Container>
    </SaaSLayout>
  );
};

export default InvoicesPage;
