import React, { useState } from 'react';
import { Container, Typography, Box, Paper, Grid, Card, CardContent, Button, Divider, CircularProgress } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import SaaSLayout from '../common/components/SaaSLayout';
import { useEffectAsync } from '../reactHelper';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import EventIcon from '@mui/icons-material/Event';

const useStyles = makeStyles()((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
  },
  card: {
    padding: theme.spacing(4),
    borderRadius: '16px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.08)',
  },
  planBadge: {
    backgroundColor: '#4caf50',
    color: '#fff',
    padding: '4px 12px',
    borderRadius: '20px',
    fontSize: '0.8rem',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  }
}));

const SubscriptionPage = () => {
  const { classes } = useStyles();
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffectAsync(async () => {
    try {
      const token = window.localStorage.getItem('geosurepath_token');
      const res = await fetch('/api/billing/subscription', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setSubscription(await res.json());
      }
    } catch (error) {
      console.error('Failed to fetch subscription:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <SaaSLayout>
        <Box display="flex" justifyContent="center" alignItems="center" height="100%">
          <CircularProgress />
        </Box>
      </SaaSLayout>
    );
  }

  return (
    <SaaSLayout>
      <Container maxWidth="md" className={classes.container}>
        <Box mb={4}>
          <Typography variant="h4" fontWeight="800" gutterBottom>My Subscription</Typography>
          <Typography variant="body1" color="textSecondary">Manage your plan and billing details.</Typography>
        </Box>

        <Paper className={classes.card}>
          <Grid container spacing={4} alignItems="center">
            <Grid item xs={12} md={7}>
               <Box display="flex" alignItems="center" mb={1}>
                  <Typography variant="h5" fontWeight="bold" mr={2}>
                    {subscription?.planId === 'STANDARD_PLAN' ? 'GeoSurePath Pro' : 'Free Trial Plan'}
                  </Typography>
                  <span className={classes.planBadge}>{subscription?.status}</span>
               </Box>
               <Typography variant="body2" color="textSecondary" gutterBottom>
                 Access to premium tracking features, engine control, and safe parking.
               </Typography>
               
               <Box mt={4} display="flex" gap={4}>
                 <Box>
                    <Typography variant="caption" color="textSecondary" display="block">RENEWAL DATE</Typography>
                    <Box display="flex" alignItems="center" mt={0.5}>
                       <EventIcon sx={{ fontSize: 18, mr: 1, color: 'primary.main' }} />
                       <Typography variant="body1" fontWeight="500">
                         {subscription?.expiresAt ? new Date(subscription.expiresAt).toLocaleDateString() : 'N/A'}
                       </Typography>
                    </Box>
                 </Box>
                 <Box>
                    <Typography variant="caption" color="textSecondary" display="block">PAYMENT METHOD</Typography>
                    <Typography variant="body1" fontWeight="500" mt={0.5}>Razorpay (Digital)</Typography>
                 </Box>
               </Box>
            </Grid>
            <Grid item xs={12} md={5} sx={{ display: 'flex', justifyContent: { md: 'flex-end', xs: 'flex-start' } }}>
               <Button variant="contained" size="large" sx={{ borderRadius: '8px', px: 4, py: 1.5, textTransform: 'none', fontWeight: 600 }}>
                 Upgrade Plan
               </Button>
            </Grid>
          </Grid>
          
          <Divider sx={{ my: 4 }} />
          
          <Box>
            <Typography variant="h6" gutterBottom>Included Features</Typography>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              {['Real-time tracking', 'Engine Control System', 'Safe Parking Geofence', 'Detailed Trip History', 'Premium Notifications'].map((feature) => (
                <Grid item xs={12} sm={6} key={feature} display="flex" alignItems="center">
                  <CheckCircleOutlineIcon sx={{ color: '#4caf50', mr: 1, fontSize: 20 }} />
                  <Typography variant="body2">{feature}</Typography>
                </Grid>
              ))}
            </Grid>
          </Box>
        </Paper>
      </Container>
    </SaaSLayout>
  );
};

export default SubscriptionPage;
