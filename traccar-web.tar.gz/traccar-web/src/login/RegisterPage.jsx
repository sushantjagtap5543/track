import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, TextField, Typography, Snackbar, IconButton, Stepper, Step, StepLabel, CircularProgress, Box } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import { useNavigate } from 'react-router-dom';
import LoginLayout from './LoginLayout';
import { useTranslation } from '../common/components/LocalizationProvider';
import { snackBarDurationShortMs } from '../common/util/duration';
import { useCatch } from '../reactHelper';
import { sessionActions } from '../store';
import BackIcon from '../common/components/BackIcon';

const useStyles = makeStyles()((theme) => ({
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(2),
  },
  title: {
    fontSize: theme.spacing(3),
    fontWeight: 500,
    marginLeft: theme.spacing(1),
    textTransform: 'uppercase',
  },
  stepper: {
    marginBottom: theme.spacing(3),
  },
  buttons: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: theme.spacing(2),
  }
}));

const steps = ['User Details', 'Vehicle', 'Device'];

const RegisterPage = () => {
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const t = useTranslation();

  const server = useSelector((state) => state.session.server);

  const [activeStep, setActiveStep] = useState(0);

  // Form State
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', password: '',
    vehicleName: '', vehicleType: '', vehicleModel: '',
    deviceImei: ''
  });

  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handleNext = () => setActiveStep((prev) => prev + 1);
  const handleBack = () => setActiveStep((prev) => prev - 1);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    
    try {
      // Call Custom SaaS API
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const data = await response.json();
        setErrorMsg(data.error || 'Registration failed');
        setSnackbarOpen(true);
        setLoading(false);
        return;
      }

      setSnackbarOpen(true);
      setTimeout(() => {
        navigate('/login');
      }, snackBarDurationShortMs);
    } catch (err) {
      setErrorMsg('Network error');
      setSnackbarOpen(true);
      setLoading(false);
    }
  };

  const isStepValid = () => {
    if (activeStep === 0) return formData.name && /(.+)@(.+)\.(.{2,})/.test(formData.email) && formData.password;
    if (activeStep === 1) return formData.vehicleName;
    if (activeStep === 2) return formData.deviceImei;
    return false;
  };

  return (
    <LoginLayout>
      <div className={classes.container}>
        <div className={classes.header}>
          {!server.newServer && (
            <IconButton color="primary" onClick={() => navigate('/login')} sx={{ mr: 1 }}>
              <BackIcon />
            </IconButton>
          )}
          <Box>
            <Typography variant="h5" sx={{ fontWeight: 800, color: 'text.primary', letterSpacing: '-0.5px' }}>
              Create Account
            </Typography>
            <Typography variant="body2" sx={{ color: 'text.secondary' }}>
              Sign up to start tracking your assets.
            </Typography>
          </Box>
        </div>

        <Stepper activeStep={activeStep} className={classes.stepper} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {activeStep === 0 && (
          <>
            <TextField required label="Full Name" name="name" value={formData.name} autoFocus onChange={handleChange} />
            <TextField required type="email" label="Email Address" name="email" value={formData.email} onChange={handleChange} />
            <TextField label="Phone Number" name="phone" value={formData.phone} onChange={handleChange} />
            <TextField required label="Password" name="password" type="password" value={formData.password} onChange={handleChange} />
          </>
        )}

        {activeStep === 1 && (
          <>
            <TextField required label="Vehicle Name (e.g., My Car)" name="vehicleName" value={formData.vehicleName} autoFocus onChange={handleChange} />
            <TextField label="Vehicle Type (Car, Truck, Bike)" name="vehicleType" value={formData.vehicleType} onChange={handleChange} />
            <TextField label="Vehicle Model" name="vehicleModel" value={formData.vehicleModel} onChange={handleChange} />
          </>
        )}

        {activeStep === 2 && (
          <>
            <TextField required label="Device IMEI / Identifier" name="deviceImei" value={formData.deviceImei} autoFocus onChange={handleChange} />
          </>
        )}

        <div className={classes.buttons}>
          <Button disabled={activeStep === 0} onClick={handleBack}>
            Back
          </Button>
          {activeStep === steps.length - 1 ? (
            <Button variant="contained" color="primary" onClick={handleSubmit} disabled={!isStepValid() || loading} sx={{ fontWeight: 600, py: 1, px: 3, borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', textTransform: 'none' }}>
              {loading ? <CircularProgress size={24} color="inherit" /> : 'Complete Registration'}
            </Button>
          ) : (
            <Button variant="contained" color="primary" onClick={handleNext} disabled={!isStepValid()} sx={{ fontWeight: 600, py: 1, px: 3, borderRadius: '8px', textTransform: 'none' }}>
              Next
            </Button>
          )}
        </div>
      </div>
      <Snackbar
        open={snackbarOpen}
        onClose={() => setSnackbarOpen(false)}
        autoHideDuration={snackBarDurationShortMs}
        message={errorMsg || 'Registration successful! Proceeding to login...'}
      />
    </LoginLayout>
  );
};

export default RegisterPage;
