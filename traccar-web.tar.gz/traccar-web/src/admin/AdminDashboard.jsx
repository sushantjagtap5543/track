import React, { useState } from 'react';
import { Container, Grid, Paper, Typography, Box, CircularProgress, Card, CardContent, LinearProgress } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import SaaSLayout from '../common/components/SaaSLayout';
import { useEffectAsync } from '../reactHelper';
import PeopleIcon from '@mui/icons-material/People';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import StorageIcon from '@mui/icons-material/Storage';

const useStyles = makeStyles()((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  card: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    borderRadius: '16px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.08)',
    transition: 'transform 0.3s ease-in-out',
    '&:hover': {
      transform: 'translateY(-5px)',
    },
  },
  statValue: {
    fontWeight: 'bold',
    fontSize: '2rem',
    margin: theme.spacing(1, 0),
  },
  iconBox: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: 50,
    height: 50,
    borderRadius: '12px',
    marginBottom: theme.spacing(1),
  },
}));

const AdminDashboard = () => {
  const { classes } = useStyles();
  const [stats, setStats] = useState(null);
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffectAsync(async () => {
    try {
      const token = window.localStorage.getItem('geosurepath_token');
      const headers = { 'Authorization': `Bearer ${token}` };

      const [statsRes, healthRes] = await Promise.all([
        fetch('/api/admin/stats', { headers }),
        fetch('/api/admin/health', { headers })
      ]);

      if (statsRes.ok && healthRes.ok) {
        setStats(await statsRes.json());
        setHealth(await healthRes.json());
      }
    } catch (error) {
      console.error('Failed to fetch admin data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <SaaSLayout>
        <Box display="flex" justifyContent="center" alignItems="center" height="100%">
          <CircularProgress />
        </Box>
      </SaaSLayout>
    );
  }

  return (
    <SaaSLayout>
      <Container maxWidth="lg" className={classes.container}>
        <Box mb={4}>
          <Typography variant="h4" fontWeight="800" color="primary" gutterBottom>
            Admin Dashboard
          </Typography>
          <Typography variant="body1" color="textSecondary">
            Overview of GeoSurePath platform performance and statistics.
          </Typography>
        </Box>

        <Grid container spacing={3}>
          {/* Statistics Section */}
          <Grid item xs={12} sm={6} md={4}>
             <Card className={classes.card}>
               <CardContent>
                 <Box className={classes.iconBox} sx={{ bgcolor: 'rgba(76, 175, 80, 0.1)', color: '#4caf50' }}>
                   <PeopleIcon />
                 </Box>
                 <Typography color="textSecondary" variant="overline">Total Clients</Typography>
                 <Typography className={classes.statValue}>{stats?.totalClients || 0}</Typography>
               </CardContent>
             </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
             <Card className={classes.card}>
               <CardContent>
                 <Box className={classes.iconBox} sx={{ bgcolor: 'rgba(33, 150, 243, 0.1)', color: '#2196f3' }}>
                   <DirectionsCarIcon />
                 </Box>
                 <Typography color="textSecondary" variant="overline">Total Vehicles</Typography>
                 <Typography className={classes.statValue}>{stats?.totalVehicles || 0}</Typography>
               </CardContent>
             </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
             <Card className={classes.card}>
               <CardContent>
                 <Box className={classes.iconBox} sx={{ bgcolor: 'rgba(255, 152, 0, 0.1)', color: '#ff9800' }}>
                   <AccountBalanceWalletIcon />
                 </Box>
                 <Typography color="textSecondary" variant="overline">Total Revenue</Typography>
                 <Typography className={classes.statValue}>₹{stats?.totalRevenue || 0}</Typography>
               </CardContent>
             </Card>
          </Grid>

          {/* System Health Section */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, borderRadius: '16px' }}>
              <Box display="flex" alignItems="center" mb={2}>
                 <StorageIcon sx={{ mr: 1, color: 'primary.main' }} />
                 <Typography variant="h6">System Resources</Typography>
              </Box>
              
              <Box mb={2}>
                <Box display="flex" justifyContent="space-between" mb={1}>
                  <Typography variant="body2">Memory Usage</Typography>
                  <Typography variant="body2" fontWeight="bold">{health?.memory?.percentageUsed}%</Typography>
                </Box>
                <LinearProgress variant="determinate" value={parseFloat(health?.memory?.percentageUsed)} sx={{ height: 8, borderRadius: 4 }} />
                <Typography variant="caption" color="textSecondary">
                  Used: {(health?.memory?.used / (1024*1024*1024)).toFixed(2)} GB / Total: {(health?.memory?.total / (1024*1024*1024)).toFixed(2)} GB
                </Typography>
              </Box>

              <Box>
                 <Typography variant="body2" gutterBottom>CPU Load (1m, 5m, 15m)</Typography>
                 <Typography variant="h6" color="primary">{health?.cpuLoad?.map(l => l.toFixed(2)).join(', ')}</Typography>
              </Box>
            </Paper>
          </Grid>

          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, borderRadius: '16px', height: '100%' }}>
              <Typography variant="h6" gutterBottom>Server Uptime</Typography>
              <Typography variant="h3" color="secondary" fontWeight="bold">
                {(health?.systemUptime / 86400).toFixed(1)} Days
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                Process Uptime: {(health?.processUptime / 3600).toFixed(1)} Hours
              </Typography>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </SaaSLayout>
  );
};

export default AdminDashboard;
