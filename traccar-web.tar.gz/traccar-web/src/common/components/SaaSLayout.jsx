import { useState, useEffect } from 'react';
import { Box, AppBar, Toolbar, Typography, IconButton, Avatar, Badge, Menu, MenuItem, Tooltip, Button } from '@mui/material';
import MapIcon from '@mui/icons-material/Map';
import DashboardIcon from '@mui/icons-material/Dashboard';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { sessionActions } from '../../store';

const SaaSLayout = ({ children }) => {
  const [notifications, setNotifications] = useState([]);
  const [notifAnchor, setNotifAnchor] = useState(null);
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [settingsAnchor, setSettingsAnchor] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();

  const role = window.localStorage.getItem('geosurepath_role') || 'CLIENT';

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await fetch('/api/notifications', {
          headers: { 'Authorization': 'Bearer ' + window.localStorage.getItem('geosurepath_token') }
        });
        if (response.ok) setNotifications(await response.json());
      } catch (e) { console.error(e); }
    };
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000); // 30 sec poll
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleLogout = () => {
    window.localStorage.removeItem('geosurepath_token');
    window.localStorage.removeItem('geosurepath_role');
    fetch('/api/session', { method: 'DELETE' });
    dispatch(sessionActions.updateUser(null));
    navigate('/login');
  };

  return (
    <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden', flexDirection: 'column' }}>
      {/* Topbar */}
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: (theme) => theme.zIndex.drawer + 1, 
          background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)', 
          boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
          borderBottom: '1px solid rgba(255,255,255,0.05)'
        }}
      >
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography 
              variant="h6" 
              noWrap 
              component="div" 
              sx={{ 
                fontWeight: 800, 
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                letterSpacing: '-0.5px'
              }}
              onClick={() => navigate('/')}
            >
              GEOSURE<span style={{ color: '#4caf50' }}>PATH</span>
              <Typography component="span" variant="caption" sx={{ ml: 1, color: 'rgba(255,255,255,0.5)', background: 'rgba(255,255,255,0.1)', px: 1, py: 0.2, borderRadius: 1 }}>{role}</Typography>
            </Typography>

            <Box sx={{ ml: 4, display: 'flex', gap: 1 }}>
              <Button 
                color="inherit" 
                startIcon={<MapIcon />} 
                onClick={() => navigate('/')}
                sx={{ 
                  textTransform: 'none', 
                  borderRadius: '8px',
                  backgroundColor: location.pathname === '/' ? 'rgba(255,255,255,0.1)' : 'transparent'
                }}
              >
                Tracking
              </Button>
              {role === 'ADMIN' && (
                <Button 
                  color="inherit" 
                  startIcon={<DashboardIcon />} 
                  onClick={() => navigate('/admin-dashboard')}
                  sx={{ 
                    textTransform: 'none', 
                    borderRadius: '8px',
                    backgroundColor: location.pathname.startsWith('/admin') ? 'rgba(255,255,255,0.1)' : 'transparent'
                  }}
                >
                  Admin
                </Button>
              )}
            </Box>
          </Box>
          
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {/* Payment & Subscription Options in Top Ribbon */}
            <Tooltip title="Subscription & Billing">
              <Button
                variant="outlined"
                color="inherit"
                startIcon={<MonetizationOnIcon sx={{ color: '#4caf50' }} />}
                onClick={() => navigate('/billing/subscription')}
                sx={{ 
                  textTransform: 'none', 
                  borderRadius: '20px', 
                  borderColor: 'rgba(255,255,255,0.3)',
                  display: { xs: 'none', sm: 'flex' },
                  mr: 1
                }}
              >
                Subscription
              </Button>
            </Tooltip>

            {/* Setting Gear Icon */}
            <Tooltip title="Settings">
              <IconButton color="inherit" onClick={(e) => setSettingsAnchor(e.currentTarget)}>
                <SettingsIcon />
              </IconButton>
            </Tooltip>
            <Menu 
              anchorEl={settingsAnchor} 
              open={Boolean(settingsAnchor)} 
              onClose={() => setSettingsAnchor(null)}
              PaperProps={{ sx: { mt: 1, boxShadow: '0 4px 20px rgba(0,0,0,0.1)' } }}
            >
              <MenuItem onClick={() => { setSettingsAnchor(null); navigate('/settings'); }}>General Settings</MenuItem>
              <MenuItem onClick={() => { setSettingsAnchor(null); navigate('/billing/subscription'); }}>Billing & Plan</MenuItem>
              <MenuItem onClick={() => { setSettingsAnchor(null); navigate('/billing/history'); }}>Payment History</MenuItem>
            </Menu>
            
            <IconButton color="inherit" onClick={(e) => setNotifAnchor(e.currentTarget)}>
              <Badge badgeContent={unreadCount} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>
            <Menu
              anchorEl={notifAnchor}
              open={Boolean(notifAnchor)}
              onClose={() => setNotifAnchor(null)}
              PaperProps={{ sx: { width: 300, maxHeight: 400, mt: 1, boxShadow: '0 4px 20px rgba(0,0,0,0.1)' } }}
            >
              <Box sx={{ p: 2, borderBottom: '1px solid #eee', fontWeight: 'bold' }}>Notifications</Box>
              {notifications.length === 0 ? (
                <MenuItem sx={{ py: 2, color: 'text.secondary' }}>No notifications</MenuItem>
              ) : (
                notifications.map((n) => (
                  <MenuItem key={n.id} onClick={() => setNotifAnchor(null)} sx={{ whiteSpace: 'normal', borderBottom: '1px solid #f9f9f9', py: 1.5 }}>
                    <Box>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>{new Date(n.createdAt).toLocaleString()}</Typography>
                      <Typography variant="body2" sx={{ fontWeight: n.isRead ? 'normal' : 'bold' }}>{n.message}</Typography>
                    </Box>
                  </MenuItem>
                ))
              )}
            </Menu>
            
            <IconButton color="inherit" onClick={(e) => setMenuAnchor(e.currentTarget)} sx={{ ml: 1 }}>
              <Avatar sx={{ width: 32, height: 32, bgcolor: '#e94560', fontSize: '0.9rem', fontWeight: 'bold' }}>U</Avatar>
            </IconButton>
            <Menu 
              anchorEl={menuAnchor} 
              open={Boolean(menuAnchor)} 
              onClose={() => setMenuAnchor(null)}
              PaperProps={{ sx: { mt: 1, boxShadow: '0 4px 20px rgba(0,0,0,0.1)' } }}
            >
              <MenuItem onClick={() => { setMenuAnchor(null); navigate('/settings'); }}>My Profile</MenuItem>
              <MenuItem onClick={() => { setMenuAnchor(null); handleLogout(); }} sx={{ color: '#e94560' }}>Logout</MenuItem>
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Main Content Area */}
      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1, 
          pt: '64px', // Width of Toolbar
          height: '100vh', 
          backgroundColor: '#f8f9fa',
          overflow: 'auto'
        }}
      >
        {children}
      </Box>
    </Box>
  );
};

export default SaaSLayout;
